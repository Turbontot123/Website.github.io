<?php
$id_telegram = "6781615836";
$id_botTele  = "7659988144:AAHaR1_AD7Z_ZfdN6d6nNHb3f9C7rHqOFiE";
?>
