<?php
$id_telegram = "7359982392";
$id_botTele  = "7078637711:AAFodylal2URfJywvr4fUW0f8lUKpBDZZt4";
?>
